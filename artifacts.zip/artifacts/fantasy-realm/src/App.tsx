import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  Backpack, BookOpen, Check, ChevronRight, CircleHelp, Coins, Crosshair, Crown,
  Flame, Heart, House, Leaf, Medal, Moon, Mountain, PawPrint, Plus, RotateCcw,
  ScrollText, Shield, Sparkles, Swords, WandSparkles, X, Zap,
  type LucideIcon,
} from "lucide-react";
import { useGame, type GamePage, type InventoryItem, type Quest } from "./game/useGame";
import { MONSTERS, REWARDED_AD_COINS } from "./game/gameReducer";
import { useRewardedAd } from "./game/useRewardedAd";

const pages: { id: GamePage; label: string; icon: LucideIcon }[] = [
  { id: "home", label: "World", icon: House },
  { id: "character", label: "Character", icon: Shield },
  { id: "inventory", label: "Inventory", icon: Backpack },
  { id: "quests", label: "Quests", icon: ScrollText },
  { id: "battle", label: "Battle", icon: Swords },
  { id: "leaderboard", label: "Hall of heroes", icon: Medal },
];

const avatarOptions: { id: string; label: string; icon: LucideIcon }[] = [
  { id: "ranger", label: "Ranger", icon: PawPrint },
  { id: "mage", label: "Mage", icon: WandSparkles },
  { id: "knight", label: "Knight", icon: Shield },
  { id: "wanderer", label: "Wanderer", icon: Mountain },
];

const monsterIcons: Record<string, LucideIcon> = {
  wolf: PawPrint,
  sprite: Flame,
  troll: Mountain,
};

const itemIcons: Record<string, LucideIcon> = {
  health: Heart,
  mana: Sparkles,
  moonstone: Moon,
};

function App() {
  const game = useGame();
  const { state } = game;
  const rewardedAd = useRewardedAd(
    import.meta.env.VITE_GAM_REWARDED_AD_UNIT?.trim(),
    game.grantRewardedAdCoins,
  );
  const [notice, setNotice] = useState("");
  const [nameDraft, setNameDraft] = useState(state.player.name);

  useEffect(() => {
    if (!state.notice) {
      setNotice("");
      return;
    }
    setNotice(state.notice);
    const timer = window.setTimeout(() => {
      game.dismissNotice();
      setNotice("");
    }, 3200);
    return () => window.clearTimeout(timer);
  }, [state.notice]);

  useEffect(() => setNameDraft(state.player.name), [state.player.name]);

  const rank = useMemo(() => {
    const board = [...state.leaderboard.filter((entry) => !entry.isPlayer), {
      name: state.player.name, level: state.player.level, xp: state.player.xp, isPlayer: true,
    }].sort((a, b) => b.level - a.level || b.xp - a.xp);
    return board.findIndex((entry) => entry.isPlayer) + 1;
  }, [state.leaderboard, state.player.level, state.player.name, state.player.xp]);

  const currentPage = pages.find((page) => page.id === state.page) ?? pages[0];
  const navigate = (page: GamePage) => game.setPage(page);

  function handleNameSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    game.renamePlayer(nameDraft);
  }

  function resetJourney() {
    if (window.confirm("Start a new journey? Your saved progress will be cleared.")) {
      game.resetGame();
      setNameDraft("Aerin");
      setNotice("A fresh journey begins in the Verdant Wilds.");
    }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true">ᚱ</div>
          <div><div className="brand-name">Fantasy Realm</div><div className="brand-sub">The Verdant Wilds</div></div>
        </div>
        <div className="nav-label">Your journey</div>
        <nav className="nav-list" aria-label="Main navigation">
          {pages.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`nav-item ${state.page === id ? "active" : ""}`} onClick={() => navigate(id)} data-testid={`nav-${id}`}>
              <span className="nav-icon"><Icon size={16} strokeWidth={1.7} /></span><span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="world-note">
            <div className="world-note-kicker"><Leaf size={12} /> Field note · 03</div>
            <p>“The old paths remember every footstep. Make yours worth keeping.”</p>
          </div>
          <button className="reset-button" onClick={resetJourney} data-testid="button-reset-game"><RotateCcw size={13} style={{ marginRight: 8, verticalAlign: "middle" }} /> Begin again</button>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="crumb">Verdant Wilds <ChevronRight size={12} style={{ verticalAlign: "middle", margin: "0 4px" }} /> {currentPage.label}</div>
          <div className="top-profile">
            <div className="top-avatar"><AvatarMark avatar={state.player.avatar} size={17} /></div>
            <div><div className="top-name" data-testid="text-player-name">{state.player.name}</div><div className="top-level">Level {state.player.level} adventurer</div></div>
          </div>
        </header>
        <div className="page-wrap" key={state.page}>
          {state.page === "home" && <HomePage state={state} navigate={navigate} rank={rank} rest={game.rest} rewardedAd={rewardedAd} />}
          {state.page === "character" && <CharacterPage state={state} nameDraft={nameDraft} setNameDraft={setNameDraft} onNameSubmit={handleNameSubmit} setAvatar={game.setAvatar} rest={game.rest} />}
          {state.page === "inventory" && <InventoryPage inventory={state.inventory} useItem={game.useItem} />}
          {state.page === "quests" && <QuestsPage quests={state.quests} acceptQuest={game.acceptQuest} claimQuest={game.claimQuest} />}
          {state.page === "battle" && <BattlePage state={state} startBattle={game.startBattle} attack={game.attack} castSpell={game.castSpell} flee={game.flee} />}
          {state.page === "leaderboard" && <LeaderboardPage state={state} rank={rank} />}
        </div>
        {rewardedAd.phase !== "closed" && <RewardedAdDialog ad={rewardedAd} />}
      </main>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {pages.map(({ id, label, icon: Icon }) => (
          <button key={id} className={state.page === id ? "active" : ""} onClick={() => navigate(id)} data-testid={`mobile-nav-${id}`}>
            <Icon strokeWidth={1.8} /><span>{label === "Hall of heroes" ? "Heroes" : label}</span>
          </button>
        ))}
      </nav>
      {notice && <div className="toast-stack" role="status" aria-live="polite"><div className="toast">{notice}</div></div>}
    </div>
  );
}

function Heading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1 className="page-title">{title}</h1>{subtitle && <p className="page-subtitle">{subtitle}</p>}</div>{action}</div>;
}

function SectionHead({ kicker, title, action }: { kicker?: string; title: string; action?: ReactNode }) {
  return <div className="panel-head"><div>{kicker && <div className="section-kicker">{kicker}</div>}<h2 className="section-title">{title}</h2></div>{action}</div>;
}

function StatMeter({ label, value, max, icon: Icon, tone }: { label: string; value: number; max: number; icon: LucideIcon; tone?: "mana" }) {
  return <div className="stat-row"><div className="stat-symbol"><Icon size={16} /></div><div className="stat-info"><div className="stat-label">{label}</div><div className="stat-value">{value}<small> / {max}</small></div><div className={`meter ${tone ?? ""}`}><span style={{ width: `${Math.max(0, Math.min(100, (value / max) * 100))}%` }} /></div></div></div>;
}

function HomePage({ state, navigate, rank, rest, rewardedAd }: { state: ReturnType<typeof useGame>["state"]; navigate: (page: GamePage) => void; rank: number; rest: () => void; rewardedAd: ReturnType<typeof useRewardedAd> }) {
  const nextQuest = state.quests.find((quest) => !quest.claimed);
  return <>
    <section className="home-hero">
      <div className="hero-copy">
        <div className="hero-kicker">A world still becoming</div>
        <h1 className="hero-title">The wilds are<br />waiting, {state.player.name}.</h1>
        <p className="hero-description">Beyond the old stone road, the forest stirs. Find your footing, follow a trail, and leave the realm a little kinder than you found it.</p>
        <div className="hero-actions"><button className="btn warm" onClick={() => navigate("battle")} data-testid="button-enter-battle"><Swords size={15} /> Enter the wilds</button><button className="btn secondary" onClick={() => navigate("quests")} data-testid="button-view-quests">View quests <ChevronRight size={14} /></button></div>
      </div>
      <div className="hero-art" aria-hidden="true"><div className="sun-disc">ᚱ</div></div>
    </section>
    <div className="home-grid">
      <div className="column-stack">
        <section className="surface panel">
          <SectionHead kicker="A thread to follow" title="Your next calling" action={<button className="inline-link" onClick={() => navigate("quests")}>All quests <ChevronRight size={12} /></button>} />
          {nextQuest ? <QuestFeature quest={nextQuest} navigate={navigate} /> : <EmptyState title="All threads complete" text="The forest is quiet—for now." />}
        </section>
        <section className="surface panel">
          <SectionHead kicker="From the field journal" title="Things worth knowing" />
          <div className="recent-list">
            <div className="recent-row"><div className="recent-icon"><Swords size={17} /></div><div className="recent-copy"><strong>{state.player.wins ? `${state.player.wins} creatures turned back` : "A first encounter awaits"}</strong><small>Every victory moves your story forward</small></div><span className="rank-badge">{state.player.wins} wins</span></div>
            <div className="recent-row"><div className="recent-icon"><Coins size={17} /></div><div className="recent-copy"><strong>{state.player.coins} coins in your purse</strong><small>The Wayfarer's Inn offers a restorative rest</small></div><button className="inline-link" onClick={rest}>Rest · 10</button></div>
            <div className="recent-row"><div className="recent-icon"><Medal size={17} /></div><div className="recent-copy"><strong>Your place among the heroes</strong><small>Local hall ranking</small></div><span className="rank-badge">#{rank}</span></div>
          </div>
        </section>
      </div>
      <div className="column-stack">
        <section className="surface panel">
          <SectionHead kicker="At a glance" title="Ready for the road" />
          <div className="stat-list">
            <StatMeter label="Vitality" value={state.player.health} max={state.player.maxHealth} icon={Heart} />
            <StatMeter label="Arcane reserve" value={state.player.mana} max={state.player.maxMana} icon={Sparkles} tone="mana" />
          </div>
        </section>
        <section className="surface panel">
          <SectionHead kicker="A small beginning" title="Your adventurer" action={<button className="inline-link" onClick={() => navigate("character")}>Details <ChevronRight size={12} /></button>} />
          <div className="recent-row" style={{ borderTop: 0, paddingTop: 2 }}>
            <div className="top-avatar" style={{ width: 45, height: 45 }}><AvatarMark avatar={state.player.avatar} size={21} /></div>
            <div className="recent-copy"><strong>{state.player.name}</strong><small>Level {state.player.level} · {state.player.xp} / {state.player.xpToNext} XP</small></div>
          </div>
          <div className="progress-line"><span style={{ width: `${Math.min(100, (state.player.xp / state.player.xpToNext) * 100)}%` }} /></div>
        </section>
        <section className="surface panel reward-ad-panel">
          <div className="reward-ad-heading">
            <div className="reward-ad-icon"><Coins size={18} /></div>
            <div>
              <div className="eyebrow">Optional reward</div>
              <h3>Coins for the road</h3>
            </div>
          </div>
          <p>Choose to watch a sponsored ad. Earn {REWARDED_AD_COINS} coins only after Google confirms the reward.</p>
          {!rewardedAd.configured && <div className="ad-setup-note">Live ads are not connected yet. A Google Ad Manager rewarded ad-unit path is needed.</div>}
          <button className="btn warm reward-ad-button" onClick={rewardedAd.openPrompt}>
            <Coins size={15} /> {rewardedAd.configured ? `Watch ad · +${REWARDED_AD_COINS} coins` : "Ad setup required"}
          </button>
        </section>
      </div>
    </div>
  </>;
}

function RewardedAdDialog({ ad }: { ad: ReturnType<typeof useRewardedAd> }) {
  const isBusy = ad.phase === "loading" || ad.phase === "showing";
  const title = ad.phase === "consent"
    ? "Earn coins by choice"
    : ad.phase === "loading"
      ? "Finding an ad"
      : ad.phase === "showing"
        ? "Your ad is playing"
        : ad.phase === "rewarded"
          ? "Reward received"
          : ad.phase === "not-earned"
            ? "No reward this time"
            : "Rewarded ads unavailable";

  return (
    <div className="reward-dialog-backdrop">
      <section className="reward-dialog" role="dialog" aria-modal="true" aria-labelledby="reward-dialog-title">
        <div className="reward-dialog-icon"><Coins size={22} /></div>
        <div className="eyebrow">Google Ad Manager · optional ad</div>
        <h2 id="reward-dialog-title">{title}</h2>
        {ad.phase === "consent" ? (
          <>
            <p>Watch a rewarded ad to earn {REWARDED_AD_COINS} coins. You can cancel, and coins are added only when Google confirms the reward.</p>
            {!ad.configured && <p className="ad-setup-note">Live ads are not connected yet. Add your rewarded ad-unit path to enable this feature.</p>}
            <div className="reward-dialog-actions">
              <button className="btn secondary" onClick={ad.closePrompt}>Cancel</button>
              <button className="btn warm" onClick={ad.continueToAd}>Continue</button>
            </div>
          </>
        ) : (
          <>
            {isBusy && <div className="reward-ad-progress" aria-hidden="true"><span /></div>}
            <p aria-live="polite">{ad.message || (isBusy ? "Please wait. You can close the ad at any time." : "")}</p>
            {!isBusy && <button className="btn warm reward-dialog-done" onClick={ad.closePrompt}>Done</button>}
          </>
        )}
      </section>
    </div>
  );
}

function QuestFeature({ quest, navigate }: { quest: Quest; navigate: (page: GamePage) => void }) {
  return <div className="quest-feature"><div className="quest-seal"><ScrollText size={18} /></div><div style={{ flex: 1 }}><h3 className="quest-feature-title">{quest.title}</h3><p className="quest-feature-desc">{quest.description}</p><div className="progress-line"><span style={{ width: `${Math.min(100, (quest.progress / quest.target) * 100)}%` }} /></div><div className="quest-meta"><span>Progress · {quest.progress} / {quest.target}</span><span className="reward">+{quest.rewardXp} XP · {quest.rewardCoins} coins</span></div><button className="inline-link" style={{ marginTop: 11, paddingLeft: 0 }} onClick={() => navigate("quests")}>Open quest book <ChevronRight size={12} /></button></div></div>;
}

function CharacterPage({ state, nameDraft, setNameDraft, onNameSubmit, setAvatar, rest }: { state: ReturnType<typeof useGame>["state"]; nameDraft: string; setNameDraft: (name: string) => void; onNameSubmit: (event: FormEvent<HTMLFormElement>) => void; setAvatar: (avatar: string) => void; rest: () => void }) {
  return <>
    <Heading eyebrow="The one who walks the path" title="Character" subtitle="Shape the hero you want the old tales to remember." />
    <div className="character-layout">
      <section className="surface character-card">
        <div className="section-kicker">Your likeness</div>
        <div className="portrait"><AvatarMark avatar={state.player.avatar} size={44} /></div>
        <h2 className="char-name">{state.player.name}</h2>
        <div className="char-class">{state.player.avatar} · wayfarer</div>
        <form className="name-edit" onSubmit={onNameSubmit}>
          <input className="text-input" value={nameDraft} onChange={(event) => setNameDraft(event.target.value)} maxLength={20} aria-label="Hero name" placeholder="Choose a name" data-testid="input-character-name" />
          <button className="btn small" type="submit" data-testid="button-save-name"><Check size={14} /> Save</button>
        </form>
        <div className="section-kicker" style={{ marginTop: 21 }}>Choose your bearing</div>
        <div className="avatar-choices">
          {avatarOptions.map(({ id, label, icon: Icon }) => <button key={id} className={`avatar-choice ${state.player.avatar === id ? "selected" : ""}`} aria-label={`Choose ${label} avatar`} title={label} onClick={() => setAvatar(id)} data-testid={`button-avatar-${id}`}><Icon size={17} /></button>)}
        </div>
      </section>
      <div className="character-right">
        <section className="level-banner">
          <div className="level-number">{state.player.level}</div><div className="level-label">Pathfinder level</div>
          <div className="xp-track"><span style={{ width: `${Math.min(100, (state.player.xp / state.player.xpToNext) * 100)}%` }} /></div>
          <div className="xp-caption"><span>{state.player.xp} experience</span><span>{state.player.xpToNext - state.player.xp} to next path</span></div>
        </section>
        <div className="attribute-grid">
          <Attribute label="Health" value={`${state.player.health} / ${state.player.maxHealth}`} detail="Vitality" icon={Heart} ratio={state.player.health / state.player.maxHealth} />
          <Attribute label="Mana" value={`${state.player.mana} / ${state.player.maxMana}`} detail="Arcane reserve" icon={Sparkles} ratio={state.player.mana / state.player.maxMana} />
          <Attribute label="Coin" value={String(state.player.coins)} detail="Purse" icon={Coins} ratio={Math.min(1, state.player.coins / 250)} />
          <Attribute label="Victories" value={String(state.player.wins)} detail="Creatures overcome" icon={Swords} ratio={Math.min(1, state.player.wins / 10)} />
        </div>
        <section className="surface panel">
          <SectionHead kicker="A pause in the journey" title="Wayfarer's Inn" />
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 15 }}>
            <p className="page-subtitle" style={{ margin: 0 }}>Restore all health and mana for 10 coins.</p><button className="btn small secondary" onClick={rest} disabled={state.player.coins < 10 || (state.player.health === state.player.maxHealth && state.player.mana === state.player.maxMana)} data-testid="button-rest">Take a rest <Plus size={13} /></button>
          </div>
        </section>
      </div>
    </div>
  </>;
}

function Attribute({ label, value, detail, icon: Icon, ratio }: { label: string; value: string; detail: string; icon: LucideIcon; ratio: number }) {
  return <div className="attribute"><div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}><div className="attribute-label">{label}</div><Icon size={15} color="#9a794b" /></div><div className="attribute-value">{value}</div><div className="meter"><span style={{ width: `${Math.max(0, Math.min(100, ratio * 100))}%`, background: label === "Health" ? "#ad6a56" : label === "Mana" ? "#64877b" : "#b38c53" }} /></div><div className="attribute-label" style={{ marginTop: 8, letterSpacing: ".02em", textTransform: "none" }}>{detail}</div></div>;
}

function InventoryPage({ inventory, useItem }: { inventory: InventoryItem[]; useItem: (id: string) => void }) {
  const [filter, setFilter] = useState<"all" | "potion" | "relic" | "material">("all");
  const visible = inventory.filter((item) => filter === "all" || item.type === filter);
  return <>
    <Heading eyebrow="What you carry" title="Inventory" subtitle="A few useful things, chosen well. The rest is yet to be found." />
    <div style={{ display: "flex", gap: 7, marginBottom: 18, flexWrap: "wrap" }}>
      {(["all", "potion", "relic", "material"] as const).map((category) => <button key={category} className={`btn small ${filter === category ? "" : "secondary"}`} onClick={() => setFilter(category)} data-testid={`filter-${category}`}>{category === "all" ? "Everything" : `${category.charAt(0).toUpperCase()}${category.slice(1)}s`}</button>)}
    </div>
    {visible.length ? <div className="inventory-grid">{visible.map((item) => <ItemCard key={item.id} item={item} useItem={useItem} />)}</div> : <EmptyState title="Nothing in this pocket" text="The road has not brought you anything of this kind yet." />}
    <div style={{ marginTop: 25, display: "flex", alignItems: "center", gap: 8, color: "#879085", fontSize: 11 }}><CircleHelp size={14} /> Potions are used immediately; relics are kept safely in your pack.</div>
  </>;
}

function ItemCard({ item, useItem }: { item: InventoryItem; useItem: (id: string) => void }) {
  const Icon = itemIcons[item.icon] ?? GemIcon;
  const isPotion = item.type === "potion";
  return <article className="surface item-card" data-testid={`card-item-${item.id}`}>
    <span className="item-kind">{item.type}</span><div className="item-art"><Icon size={23} strokeWidth={1.5} /></div>
    <h3 className="item-name">{item.name}</h3><p className="item-description">{item.description}</p>
    <div className="item-bottom"><span className="item-qty">Quantity · {item.quantity}</span><button className="btn small secondary" disabled={!isPotion || item.quantity <= 0} onClick={() => useItem(item.id)} data-testid={`button-use-${item.id}`}>{isPotion ? "Use" : "Kept"}</button></div>
  </article>;
}

function GemIcon({ size = 23 }: { size?: number }) {
  return <Mountain size={size} strokeWidth={1.5} />;
}

function QuestsPage({ quests, acceptQuest, claimQuest }: { quests: Quest[]; acceptQuest: (id: string) => void; claimQuest: (id: string) => void }) {
  const active = quests.filter((quest) => quest.accepted && !quest.claimed);
  const available = quests.filter((quest) => !quest.accepted && !quest.claimed);
  const completed = quests.filter((quest) => quest.claimed);
  return <>
    <Heading eyebrow="The forest keeps its promises" title="Quest book" subtitle="Take on a calling, make progress at your own pace, and claim what you have earned." />
    {active.length > 0 && <QuestGroup kicker="In progress" quests={active} acceptQuest={acceptQuest} claimQuest={claimQuest} />}
    {available.length > 0 && <QuestGroup kicker="Open callings" quests={available} acceptQuest={acceptQuest} claimQuest={claimQuest} />}
    {completed.length > 0 && <QuestGroup kicker="Written into the journal" quests={completed} acceptQuest={acceptQuest} claimQuest={claimQuest} />}
    {quests.length === 0 && <EmptyState title="A blank page" text="There are no callings in the book yet." />}
  </>;
}

function QuestGroup({ kicker, quests, acceptQuest, claimQuest }: { kicker: string; quests: Quest[]; acceptQuest: (id: string) => void; claimQuest: (id: string) => void }) {
  return <section style={{ marginBottom: 27 }}><div className="section-kicker" style={{ marginBottom: 12 }}>{kicker}</div><div className="quest-list">{quests.map((quest) => <QuestCard key={quest.id} quest={quest} acceptQuest={acceptQuest} claimQuest={claimQuest} />)}</div></section>;
}

function QuestCard({ quest, acceptQuest, claimQuest }: { quest: Quest; acceptQuest: (id: string) => void; claimQuest: (id: string) => void }) {
  const complete = quest.progress >= quest.target;
  return <article className="surface quest-card" data-testid={`card-quest-${quest.id}`}>
    <div className="quest-symbol">{quest.claimed ? <Check size={18} /> : <ScrollText size={18} />}</div>
    <div><h3 className="quest-title">{quest.title}</h3><p className="quest-desc">{quest.description}</p>
      {quest.accepted && !quest.claimed && <><div className="progress-line"><span style={{ width: `${Math.min(100, (quest.progress / quest.target) * 100)}%` }} /></div><div className="quest-meta"><span>Objective · {quest.progress} / {quest.target}</span><span className="reward">+{quest.rewardXp} XP · {quest.rewardCoins} coins</span></div></>}
      {(!quest.accepted || quest.claimed) && <div className="quest-reward">Reward · +{quest.rewardXp} XP · {quest.rewardCoins} coins</div>}
    </div>
    <div className="quest-action">{quest.claimed ? <span className="quest-complete"><Check size={13} /> Claimed</span> : quest.accepted ? <button className={`btn small ${complete ? "warm" : "secondary"}`} disabled={!complete} onClick={() => claimQuest(quest.id)} data-testid={`button-claim-${quest.id}`}>{complete ? "Claim reward" : "In progress"}</button> : <button className="btn small" onClick={() => acceptQuest(quest.id)} data-testid={`button-accept-${quest.id}`}>Accept <ChevronRight size={13} /></button>}</div>
  </article>;
}

function BattlePage({ state, startBattle, attack, castSpell, flee }: { state: ReturnType<typeof useGame>["state"]; startBattle: (id: string) => void; attack: () => void; castSpell: () => void; flee: () => void }) {
  const battle = state.battle;
  const Icon = battle ? monsterIcons[battle.monsterIcon] ?? PawPrint : PawPrint;
  const isActive = Boolean(battle && !battle.isOver);
  return <>
    <Heading eyebrow="Steel, spell, and nerve" title="The clearing" subtitle="Choose a creature to challenge, then trust your instincts." action={<div className="rank-badge">Turn-based encounters</div>} />
    <div className="battle-layout">
      <section className="battle-arena">
        <div className="arena-sky" />
        <div className="arena-header"><span>Moonlit clearing</span><span>{battle ? `Turn ${battle.turn}` : "No encounter"}</span></div>
        {battle ? <div style={{ position: "relative", zIndex: 1 }}>
          <div className="arena-battlefield">
            <Fighter name={state.player.name} avatar={state.player.avatar} value={state.player.health} max={state.player.maxHealth} player />
            <div className="vs-mark">against</div>
            <Fighter name={battle.monsterName} icon={Icon} value={battle.health} max={battle.maxHealth} enemy />
          </div>
          {battle.isOver ? <div className="battle-outcome">{battle.won ? <><Check size={14} /> Victory · the path is clear</> : <><Shield size={14} /> Defeated · the healer saw you home</>}</div> : <div className="battle-actions">
            <button className="btn warm" onClick={attack} data-testid="button-attack"><Swords size={15} /> Strike</button>
            <button className="btn secondary" onClick={castSpell} disabled={state.player.mana < 14} data-testid="button-cast-spell"><Zap size={14} /> Arcane bolt · 14</button>
            <button className="btn danger" onClick={flee} data-testid="button-flee"><X size={14} /> Retreat</button>
          </div>}
        </div> : <div className="arena-empty"><div className="empty-mark"><Crosshair size={21} /></div><h3>Let the forest choose</h3><p>Pick a creature nearby. Some are quick, some are sturdy. Each encounter brings experience and a little coin.</p></div>}
      </section>
      <section className="surface battle-log">
        <SectionHead kicker={battle ? "The tale so far" : "Find a worthy foe"} title={battle ? "Battle log" : "Nearby creatures"} />
        {battle && isActive ? <><div className="log-entries">{battle.log.map((line, index) => <div className="log-entry" key={`${line}-${index}`}><span className="log-time">{String(Math.max(1, battle.turn - index)).padStart(2, "0")}</span><span>{line}</span></div>)}</div>
          <div style={{ marginTop: "auto", paddingTop: 17, color: "#879085", fontSize: 10 }}>Use a potion from your inventory if the tide turns.</div>
        </> : <>{battle && <div className="battle-outcome" style={{ justifyContent: "flex-start", padding: "0 0 12px", color: "#687b69" }}>{battle.won ? "A victory worth remembering." : "The healer has sent you back to the path."}</div>}<div className="monster-list">{MONSTERS.map((monster) => {
          const MonsterIcon = monsterIcons[monster.icon] ?? PawPrint;
          return <button className="monster-choice" key={monster.id} onClick={() => startBattle(monster.id)} data-testid={`button-fight-${monster.id}`}><span className="monster-icon"><MonsterIcon size={20} /></span><span className="monster-info"><strong>{monster.name}</strong><small>{monster.health} vitality · {monster.damage} strike</small></span><ChevronRight size={15} /></button>;
        })}</div></>}
      </section>
    </div>
  </>;
}

function Fighter({ name, avatar, icon: EnemyIcon, value, max, player, enemy }: { name: string; avatar?: string; icon?: LucideIcon; value: number; max: number; player?: boolean; enemy?: boolean }) {
  const Icon = EnemyIcon ?? PawPrint;
  return <div className={`fighter ${enemy ? "enemy" : ""}`}>
    <div className="fighter-portrait">{player ? <AvatarMark avatar={avatar ?? "ranger"} size={43} /> : <Icon size={47} strokeWidth={1.25} />}</div>
    <div className="fighter-name">{name}</div><div className="health-wrap"><div className="health-copy"><span>{player ? "VITALITY" : "CREATURE"}</span><span>{value} / {max}</span></div><div className={`healthbar ${player ? "playerbar" : ""}`}><span style={{ width: `${Math.max(0, Math.min(100, (value / max) * 100))}%` }} /></div></div>
  </div>;
}

function LeaderboardPage({ state, rank }: { state: ReturnType<typeof useGame>["state"]; rank: number }) {
  const rows = [...state.leaderboard.filter((entry) => !entry.isPlayer), { name: state.player.name, level: state.player.level, xp: state.player.xp, isPlayer: true }]
    .sort((a, b) => b.level - a.level || b.xp - a.xp);
  return <>
    <Heading eyebrow="Names carried forward" title="Hall of heroes" subtitle="A quiet local record of the heroes whose paths are written in this realm." />
    <section className="surface leaderboard-table" aria-label="Local heroes leaderboard">
      <div className="leader-head"><span>Place</span><span>Adventurer</span><span>Level</span><span>Experience</span></div>
      {rows.map((entry, index) => <div className={`leader-row ${entry.isPlayer ? "is-player" : ""}`} key={`${entry.name}-${index}`} data-testid={`row-hero-${entry.name.toLowerCase()}`}>
        <span className="rank-num">{String(index + 1).padStart(2, "0")}</span>
        <div className="leader-hero"><div className="leader-avatar">{entry.isPlayer ? <AvatarMark avatar={state.player.avatar} size={17} /> : <Crown size={16} />}</div><div style={{ minWidth: 0 }}><div className="leader-name">{entry.name}</div>{entry.isPlayer && <div className="leader-tag">Your place</div>}</div></div>
        <span className="leader-level">Lv. {entry.level}</span><span className="leader-xp">{entry.xp} XP</span>
      </div>)}
    </section>
    <div className="rank-banner"><div className="rank-medal"><Medal size={21} /></div><div><strong>You stand at place {rank}.</strong><span>Keep exploring. The hall changes as your own story grows.</span></div></div>
    <div style={{ marginTop: 18, color: "#849084", fontSize: 11, lineHeight: 1.6 }}>This is a saved, single-player hall of heroes. Your current character is ranked alongside the realm's recorded names.</div>
  </>;
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><div className="empty-mark"><BookOpen size={21} /></div><strong style={{ display: "block", fontFamily: "var(--app-font-serif)", fontSize: 19, color: "#365440", fontWeight: 500 }}>{title}</strong><p style={{ margin: "7px 0 0", fontSize: 12 }}>{text}</p></div>;
}

function AvatarMark({ avatar, size }: { avatar: string; size: number }) {
  const option = avatarOptions.find((candidate) => candidate.id === avatar) ?? avatarOptions[0];
  const Icon = option.icon;
  return <Icon size={size} strokeWidth={1.65} />;
}

export default App;
