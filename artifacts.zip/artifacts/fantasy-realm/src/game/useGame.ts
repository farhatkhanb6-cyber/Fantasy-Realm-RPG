import { useEffect, useReducer } from "react";
import { createInitialState, gameReducer, loadSavedState } from "./gameReducer";
import { browserGameStore, type GameSaveStore } from "./gameStorage";
import type { GamePage } from "./types";

export function useGame(store: GameSaveStore = browserGameStore) {
  const [state, dispatch] = useReducer(gameReducer, undefined, () =>
    loadSavedState(store.load()),
  );

  useEffect(() => {
    try {
      store.save(state);
    } catch {
      // The game remains usable if browser storage is unavailable.
    }
  }, [state, store]);

  return {
    state,
    setPage: (page: GamePage) => dispatch({ type: "set-page", page }),
    renamePlayer: (name: string) => dispatch({ type: "rename", name }),
    setAvatar: (avatar: string) => dispatch({ type: "avatar", avatar }),
    startBattle: (monsterId: string) => dispatch({ type: "start-battle", monsterId }),
    attack: () => dispatch({ type: "attack" }),
    castSpell: () => dispatch({ type: "cast-spell" }),
    flee: () => dispatch({ type: "flee" }),
    acceptQuest: (questId: string) => dispatch({ type: "accept-quest", questId }),
    claimQuest: (questId: string) => dispatch({ type: "claim-quest", questId }),
    grantRewardedAdCoins: () => dispatch({ type: "ad-reward" }),
    useItem: (itemId: string) => dispatch({ type: "use-item", itemId }),
    rest: () => dispatch({ type: "rest" }),
    dismissNotice: () => dispatch({ type: "dismiss-notice" }),
    resetGame: () => {
      try {
        store.clear();
      } catch {
        // The game can still restart even if storage is unavailable.
      }
      dispatch({ type: "reset" });
    },
  };
}

export { createInitialState };
export type {
  Battle,
  GamePage,
  GameState,
  InventoryItem,
  ItemType,
  LeaderboardEntry,
  Player,
  Quest,
} from "./types";
