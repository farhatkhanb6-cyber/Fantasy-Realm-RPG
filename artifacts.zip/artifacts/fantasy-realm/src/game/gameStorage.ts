import type { GameState } from "./types";
import { SAVE_KEY } from "./gameReducer";

export interface GameSaveStore {
  load(): string | null;
  save(state: GameState): void;
  clear(): void;
}

export const browserGameStore: GameSaveStore = {
  load: () => window.localStorage.getItem(SAVE_KEY),
  save: (state) => window.localStorage.setItem(SAVE_KEY, JSON.stringify(state)),
  clear: () => window.localStorage.removeItem(SAVE_KEY),
};
