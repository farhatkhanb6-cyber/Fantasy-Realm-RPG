interface GoogleAdSlot {
  addService(service: GooglePubAds): GoogleAdSlot;
}

interface GoogleAdEvent {
  slot?: GoogleAdSlot;
  isEmpty?: boolean;
  makeRewardedVisible?: () => boolean;
}

interface GooglePubAds {
  addEventListener(
    eventName: string,
    listener: (event: GoogleAdEvent) => void,
  ): void;
  removeEventListener(
    eventName: string,
    listener: (event: GoogleAdEvent) => void,
  ): void;
}

interface GoogleTag {
  apiReady?: boolean;
  cmd: { push(callback: () => void): void };
  enums: { OutOfPageFormat: { REWARDED: string } };
  defineOutOfPageSlot(unitPath: string, format: string): GoogleAdSlot | null;
  pubads(): GooglePubAds;
  enableServices(): void;
  display(slot: GoogleAdSlot): void;
  destroySlots(slots: GoogleAdSlot[]): void;
}

declare global {
  interface Window {
    googletag?: GoogleTag;
  }
}

export interface RewardedAdCallbacks {
  onShowing: () => void;
  onRewardGranted: () => void;
  onClosed: (rewarded: boolean) => void;
  onUnavailable: (message: string) => void;
}

let gptLoad: Promise<GoogleTag> | undefined;
let activeRequest = false;

function loadGoogleTag(): Promise<GoogleTag> {
  if (window.googletag?.apiReady) return Promise.resolve(window.googletag);
  if (gptLoad) return gptLoad;

  window.googletag =
    window.googletag ?? ({ cmd: [] } as unknown as GoogleTag);
  gptLoad = new Promise<GoogleTag>((resolve, reject) => {
    let script = document.querySelector<HTMLScriptElement>(
      'script[data-fantasy-realm-gpt="true"]',
    );
    if (!script) {
      script = document.createElement("script");
      script.src = "https://securepubads.g.doubleclick.net/tag/js/gpt.js";
      script.async = true;
      script.dataset.fantasyRealmGpt = "true";
      document.head.appendChild(script);
    }

    const timeout = window.setTimeout(() => {
      gptLoad = undefined;
      reject(new Error("Google Ad Manager did not respond in time."));
    }, 15_000);

    script.addEventListener(
      "error",
      () => {
        window.clearTimeout(timeout);
        gptLoad = undefined;
        reject(new Error("Google Ad Manager could not be loaded."));
      },
      { once: true },
    );

    window.googletag!.cmd.push(() => {
      window.clearTimeout(timeout);
      resolve(window.googletag!);
    });
  });
  return gptLoad;
}

export function requestGoogleRewardedAd(
  adUnitPath: string,
  callbacks: RewardedAdCallbacks,
): () => void {
  let disposed = false;
  let gpt: GoogleTag | undefined;
  let slot: GoogleAdSlot | undefined;
  let readyTimeout = 0;
  let listeners: Array<{
    event: string;
    listener: (event: GoogleAdEvent) => void;
  }> = [];
  let rewarded = false;

  const cleanup = () => {
    if (readyTimeout) window.clearTimeout(readyTimeout);
    if (gpt && slot) {
      for (const { event, listener } of listeners) {
        gpt.pubads().removeEventListener(event, listener);
      }
      gpt.destroySlots([slot]);
    }
    listeners = [];
    slot = undefined;
    activeRequest = false;
  };

  const fail = (message: string) => {
    if (disposed) return;
    cleanup();
    callbacks.onUnavailable(message);
  };

  if (activeRequest) {
    callbacks.onUnavailable("An ad is already being prepared.");
    return () => {};
  }
  activeRequest = true;
  readyTimeout = window.setTimeout(
    () => fail("No ad became available. Please try again later."),
    20_000,
  );

  void loadGoogleTag()
    .then((loadedGpt) => {
      if (disposed) return;
      gpt = loadedGpt;
      gpt.cmd.push(() => {
        if (disposed) return;
        try {
          const adSlot = gpt!.defineOutOfPageSlot(
            adUnitPath,
            gpt!.enums.OutOfPageFormat.REWARDED,
          );
          if (!adSlot) {
            fail("Rewarded ads are not available on this browser or page.");
            return;
          }
          slot = adSlot.addService(gpt!.pubads());

          const listen = (
            event: string,
            listener: (event: GoogleAdEvent) => void,
          ) => {
            gpt!.pubads().addEventListener(event, listener);
            listeners.push({ event, listener });
          };

          listen("rewardedSlotReady", (event) => {
            if (event.slot !== slot || disposed) return;
            window.clearTimeout(readyTimeout);
            readyTimeout = 0;
            if (event.makeRewardedVisible?.()) {
              callbacks.onShowing();
            } else {
              fail("The rewarded ad could not be displayed.");
            }
          });

          listen("rewardedSlotGranted", (event) => {
            if (event.slot !== slot || disposed || rewarded) return;
            rewarded = true;
            callbacks.onRewardGranted();
          });

          listen("rewardedSlotClosed", (event) => {
            if (event.slot !== slot || disposed) return;
            cleanup();
            callbacks.onClosed(rewarded);
          });

          listen("slotRenderEnded", (event) => {
            if (event.slot === slot && event.isEmpty) {
              fail("No rewarded ad is available right now.");
            }
          });

          gpt!.enableServices();
          gpt!.display(slot);
        } catch {
          fail("The rewarded ad could not be started.");
        }
      });
    })
    .catch((error: unknown) => {
      fail(
        error instanceof Error
          ? error.message
          : "Google Ad Manager could not be loaded.",
      );
    });

  return () => {
    disposed = true;
    cleanup();
  };
}
