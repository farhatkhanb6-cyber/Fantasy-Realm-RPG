import type {
  Battle,
  GamePage,
  GameState,
  InventoryItem,
  LeaderboardEntry,
  Quest,
} from "./types";

export const SAVE_KEY = "fantasy-realm-save-v1";
export const REWARDED_AD_COINS = 50;

export const MONSTERS = [
  {
    id: "moss-wolf",
    name: "Mossfang Wolf",
    icon: "wolf",
    health: 38,
    damage: 7,
    xp: 34,
    coins: 16,
  },
  {
    id: "ember-sprite",
    name: "Ember Sprite",
    icon: "sprite",
    health: 31,
    damage: 9,
    xp: 39,
    coins: 21,
  },
  {
    id: "stone-troll",
    name: "Stoneback Troll",
    icon: "troll",
    health: 58,
    damage: 8,
    xp: 54,
    coins: 32,
  },
] as const;

const startingInventory: InventoryItem[] = [
  {
    id: "health-potion",
    name: "Health Potion",
    description: "Restores 35 health during an adventure.",
    quantity: 3,
    type: "potion",
    icon: "health",
  },
  {
    id: "mana-elixir",
    name: "Mana Elixir",
    description: "Restores 25 mana for another spell.",
    quantity: 2,
    type: "potion",
    icon: "mana",
  },
  {
    id: "moonstone",
    name: "Moonstone",
    description: "A cool, luminous shard found along the old road.",
    quantity: 1,
    type: "relic",
    icon: "moonstone",
  },
];

const startingQuests: Quest[] = [
  {
    id: "first-hunt",
    title: "A First Hunt",
    description: "Defeat a creature threatening the Verdant Wilds.",
    progress: 0,
    target: 1,
    rewardXp: 45,
    rewardCoins: 25,
    accepted: true,
    claimed: false,
  },
  {
    id: "wilds-guardian",
    title: "Guardian of the Wilds",
    description: "Drive back three creatures from the forest paths.",
    progress: 0,
    target: 3,
    rewardXp: 90,
    rewardCoins: 60,
    accepted: false,
    claimed: false,
  },
  {
    id: "keep-your-strength",
    title: "Keep Your Strength",
    description: "Use a health potion while exploring.",
    progress: 0,
    target: 1,
    rewardXp: 30,
    rewardCoins: 20,
    accepted: false,
    claimed: false,
  },
];

export function createInitialState(): GameState {
  return {
    player: {
      name: "Aerin",
      avatar: "ranger",
      level: 1,
      xp: 0,
      xpToNext: 100,
      health: 100,
      maxHealth: 100,
      mana: 60,
      maxMana: 60,
      coins: 75,
      wins: 0,
    },
    inventory: startingInventory.map((item) => ({ ...item })),
    quests: startingQuests.map((quest) => ({ ...quest })),
    battle: null,
    leaderboard: [
      { name: "Elowen", level: 8, xp: 725, isPlayer: false },
      { name: "Thorne", level: 6, xp: 548, isPlayer: false },
      { name: "Nyx", level: 5, xp: 416, isPlayer: false },
      { name: "Cael", level: 3, xp: 227, isPlayer: false },
    ],
    page: "home",
    notice: "Your journey begins in the Verdant Wilds.",
  };
}

export function loadSavedState(saved: string | null): GameState {
  try {
    if (!saved) return createInitialState();
    const parsed = JSON.parse(saved) as Partial<GameState>;
    const initial = createInitialState();
    return {
      ...initial,
      ...parsed,
      player: { ...initial.player, ...parsed.player },
      inventory: Array.isArray(parsed.inventory)
        ? parsed.inventory
        : initial.inventory,
      quests: Array.isArray(parsed.quests) ? parsed.quests : initial.quests,
      leaderboard: Array.isArray(parsed.leaderboard)
        ? parsed.leaderboard
        : initial.leaderboard,
      battle: parsed.battle ?? null,
      page: isGamePage(parsed.page) ? parsed.page : "home",
    };
  } catch {
    return createInitialState();
  }
}

type Action =
  | { type: "set-page"; page: GamePage }
  | { type: "rename"; name: string }
  | { type: "avatar"; avatar: string }
  | { type: "start-battle"; monsterId: string }
  | { type: "attack" }
  | { type: "cast-spell" }
  | { type: "flee" }
  | { type: "accept-quest"; questId: string }
  | { type: "claim-quest"; questId: string }
  | { type: "ad-reward" }
  | { type: "use-item"; itemId: string }
  | { type: "rest" }
  | { type: "dismiss-notice" }
  | { type: "reset" };

export function gameReducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case "set-page":
      return { ...state, page: action.page, notice: "" };
    case "rename": {
      const name = action.name.trim().slice(0, 20);
      if (!name) return { ...state, notice: "Choose a name for your hero." };
      return { ...state, player: { ...state.player, name }, notice: "Your name has been updated." };
    }
    case "avatar":
      return {
        ...state,
        player: { ...state.player, avatar: action.avatar },
        notice: "Your new look is ready for the road.",
      };
    case "start-battle":
      return startBattle(state, action.monsterId);
    case "attack":
      return takePlayerTurn(state, "attack");
    case "cast-spell":
      return takePlayerTurn(state, "spell");
    case "flee":
      return {
        ...state,
        battle: null,
        page: "battle",
        notice: "You escaped safely. The forest will still be here.",
      };
    case "accept-quest":
      return {
        ...state,
        quests: state.quests.map((quest) =>
          quest.id === action.questId ? { ...quest, accepted: true } : quest,
        ),
        notice: "Quest accepted. Your progress will be tracked.",
      };
    case "claim-quest":
      return claimQuest(state, action.questId);
    case "ad-reward":
      return {
        ...state,
        player: {
          ...state.player,
          coins: state.player.coins + REWARDED_AD_COINS,
        },
        notice: `Reward confirmed! +${REWARDED_AD_COINS} coins.`,
      };
    case "use-item":
      return useItem(state, action.itemId);
    case "rest":
      if (state.player.health === state.player.maxHealth && state.player.mana === state.player.maxMana) {
        return { ...state, notice: "You are already well rested." };
      }
      if (state.player.coins < 10) {
        return { ...state, notice: "You need 10 coins to rest at the Wayfarer's Inn." };
      }
      return {
        ...state,
        player: {
          ...state.player,
          coins: state.player.coins - 10,
          health: state.player.maxHealth,
          mana: state.player.maxMana,
        },
        notice: "A warm meal restores your health and mana. (10 coins)",
      };
    case "dismiss-notice":
      return { ...state, notice: "" };
    case "reset":
      return createInitialState();
    default:
      return state;
  }
}

function startBattle(state: GameState, monsterId: string): GameState {
  if (state.battle && !state.battle.isOver) {
    return { ...state, page: "battle", notice: "Finish your current encounter first." };
  }
  const monster = MONSTERS.find((candidate) => candidate.id === monsterId);
  if (!monster) return { ...state, notice: "That creature could not be found." };
  const levelScale = Math.max(0, state.player.level - 1);
  const maxHealth = monster.health + levelScale * 8;
  return {
    ...state,
    page: "battle",
    battle: {
      monsterId: monster.id,
      monsterName: monster.name,
      monsterIcon: monster.icon,
      health: maxHealth,
      maxHealth,
      damage: monster.damage + Math.floor(levelScale * 1.5),
      turn: 1,
      log: [`A ${monster.name} blocks the forest path.`],
      isOver: false,
      won: false,
    },
    notice: `A ${monster.name} approaches!`,
  };
}

function takePlayerTurn(state: GameState, move: "attack" | "spell"): GameState {
  const battle = state.battle;
  if (!battle || battle.isOver) return state;
  const { player } = state;
  if (move === "spell" && player.mana < 14) {
    return { ...state, notice: "You need at least 14 mana to cast Arcane Bolt." };
  }

  const damage =
    move === "spell"
      ? 19 + player.level * 3 + randomInt(-2, 4)
      : 11 + player.level * 2 + randomInt(-3, 5);
  const remainingMonsterHealth = Math.max(0, battle.health - damage);
  const actionLine =
    move === "spell"
      ? `Arcane Bolt deals ${damage} damage.`
      : `You strike for ${damage} damage.`;
  const afterPlayerTurn: Battle = {
    ...battle,
    health: remainingMonsterHealth,
    turn: battle.turn + 1,
    log: [actionLine, ...battle.log].slice(0, 8),
  };
  const mana = move === "spell" ? player.mana - 14 : player.mana;

  if (remainingMonsterHealth === 0) {
    return winBattle(state, afterPlayerTurn, mana, actionLine);
  }

  const incomingDamage = Math.max(1, battle.damage + randomInt(-2, 2));
  const remainingPlayerHealth = Math.max(0, player.health - incomingDamage);
  const afterMonsterTurn: Battle = {
    ...afterPlayerTurn,
    log: [`${battle.monsterName} hits you for ${incomingDamage}.`, ...afterPlayerTurn.log].slice(0, 8),
  };
  if (remainingPlayerHealth === 0) {
    return {
      ...state,
      player: {
        ...player,
        health: Math.ceil(player.maxHealth * 0.35),
        mana,
        coins: Math.max(0, player.coins - Math.ceil(player.coins * 0.1)),
      },
      battle: {
        ...afterMonsterTurn,
        isOver: true,
        won: false,
        log: ["You fall back to the Wayfarer's Inn, where the healer tends your wounds.", ...afterMonsterTurn.log].slice(0, 8),
      },
      notice: "Defeat. The healer brought you back, but you lost 10% of your coins.",
    };
  }
  return {
    ...state,
    player: { ...player, health: remainingPlayerHealth, mana },
    battle: afterMonsterTurn,
    notice: "",
  };
}

function winBattle(
  state: GameState,
  battle: Battle,
  mana: number,
  lastMove: string,
): GameState {
  const monster = MONSTERS.find((candidate) => candidate.id === battle.monsterId);
  if (!monster) return state;
  const xp = monster.xp + Math.max(0, state.player.level - 1) * 8;
  const coins = monster.coins + randomInt(0, 7);
  const player = awardXp(
    {
      ...state.player,
      mana,
      coins: state.player.coins + coins,
      wins: state.player.wins + 1,
    },
    xp,
  );
  const quests = updateQuestProgress(state.quests);
  const inventory = state.inventory.map((item) =>
    item.id === "moonstone" && Math.random() < 0.18
      ? { ...item, quantity: item.quantity + 1 }
      : item,
  );
  const lootLine =
    inventory.find((item) => item.id === "moonstone")!.quantity >
    state.inventory.find((item) => item.id === "moonstone")!.quantity
      ? " A Moonstone joins your pack."
      : "";
  const victoryText = `${battle.monsterName} is defeated! +${xp} XP, +${coins} coins.${lootLine}`;
  return {
    ...state,
    player,
    inventory,
    quests,
    battle: {
      ...battle,
      isOver: true,
      won: true,
      log: [victoryText, lastMove, ...battle.log].slice(0, 8),
    },
    notice: victoryText,
  };
}

function claimQuest(state: GameState, questId: string): GameState {
  const quest = state.quests.find((candidate) => candidate.id === questId);
  if (!quest || !quest.accepted || quest.claimed || quest.progress < quest.target) {
    return { ...state, notice: "Complete the quest objectives before claiming your reward." };
  }
  const quests = state.quests.map((candidate) =>
    candidate.id === questId ? { ...candidate, claimed: true } : candidate,
  );
  const player = awardXp(
    { ...state.player, coins: state.player.coins + quest.rewardCoins },
    quest.rewardXp,
  );
  return {
    ...state,
    quests,
    player,
    notice: `Quest complete! +${quest.rewardXp} XP and +${quest.rewardCoins} coins.`,
  };
}

function useItem(state: GameState, itemId: string): GameState {
  const item = state.inventory.find((candidate) => candidate.id === itemId);
  if (!item || item.quantity <= 0) {
    return { ...state, notice: "You do not have any of that item left." };
  }
  if (item.id === "health-potion") {
    if (state.player.health >= state.player.maxHealth) {
      return { ...state, notice: "Your health is already full." };
    }
    const quests = state.quests.map((quest) =>
      quest.id === "keep-your-strength" && quest.accepted
        ? { ...quest, progress: Math.min(quest.target, quest.progress + 1) }
        : quest,
    );
    return {
      ...state,
      player: { ...state.player, health: Math.min(state.player.maxHealth, state.player.health + 35) },
      inventory: decrementItem(state.inventory, itemId),
      quests,
      notice: "Health Potion used. You feel stronger.",
    };
  }
  if (item.id === "mana-elixir") {
    if (state.player.mana >= state.player.maxMana) {
      return { ...state, notice: "Your mana is already full." };
    }
    return {
      ...state,
      player: { ...state.player, mana: Math.min(state.player.maxMana, state.player.mana + 25) },
      inventory: decrementItem(state.inventory, itemId),
      notice: "Mana Elixir used. Your magic returns.",
    };
  }
  return { ...state, notice: "This relic is best kept safe in your pack." };
}

function decrementItem(items: InventoryItem[], itemId: string): InventoryItem[] {
  return items.map((item) =>
    item.id === itemId ? { ...item, quantity: Math.max(0, item.quantity - 1) } : item,
  );
}

function updateQuestProgress(quests: Quest[]): Quest[] {
  return quests.map((quest) =>
    quest.id === "first-hunt" || quest.id === "wilds-guardian"
      ? {
          ...quest,
          progress: quest.accepted ? Math.min(quest.target, quest.progress + 1) : quest.progress,
        }
      : quest,
  );
}

function awardXp(player: GameState["player"], amount: number): GameState["player"] {
  let level = player.level;
  let xp = player.xp + amount;
  let xpToNext = player.xpToNext;
  let maxHealth = player.maxHealth;
  let maxMana = player.maxMana;
  while (xp >= xpToNext) {
    xp -= xpToNext;
    level += 1;
    xpToNext = Math.round(100 * Math.pow(level, 1.18));
    maxHealth += 14;
    maxMana += 8;
  }
  const levelUps = level - player.level;
  return {
    ...player,
    level,
    xp,
    xpToNext,
    maxHealth,
    maxMana,
    health: Math.min(maxHealth, player.health + levelUps * 14),
    mana: Math.min(maxMana, player.mana + levelUps * 8),
  };
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function isGamePage(value: unknown): value is GamePage {
  return (
    value === "home" ||
    value === "character" ||
    value === "inventory" ||
    value === "quests" ||
    value === "battle" ||
    value === "leaderboard"
  );
}

export function getLeaderboard(state: GameState): LeaderboardEntry[] {
  return [
    ...state.leaderboard.filter((entry) => !entry.isPlayer),
    {
      name: state.player.name,
      level: state.player.level,
      xp: state.player.xp,
      isPlayer: true,
    },
  ].sort((left, right) => right.level - left.level || right.xp - left.xp);
}
