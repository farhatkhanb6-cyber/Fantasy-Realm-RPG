import { useEffect, useRef, useState } from "react";
import { requestGoogleRewardedAd } from "./googleRewardedAd";

export type RewardedAdPhase =
  | "closed"
  | "consent"
  | "loading"
  | "showing"
  | "rewarded"
  | "not-earned"
  | "unavailable";

export function useRewardedAd(
  adUnitPath: string | undefined,
  onRewardGranted: () => void,
) {
  const [phase, setPhase] = useState<RewardedAdPhase>("closed");
  const [message, setMessage] = useState("");
  const cancelRequest = useRef<() => void>(() => {});
  const rewardCallback = useRef(onRewardGranted);

  useEffect(() => {
    rewardCallback.current = onRewardGranted;
  }, [onRewardGranted]);

  useEffect(
    () => () => {
      cancelRequest.current();
    },
    [],
  );

  function openPrompt() {
    setMessage("");
    setPhase("consent");
  }

  function closePrompt() {
    if (phase === "loading" || phase === "showing") return;
    cancelRequest.current();
    setPhase("closed");
    setMessage("");
  }

  function continueToAd() {
    if (!adUnitPath) {
      setMessage("Live ads are not configured yet. Add your Google Ad Manager rewarded ad-unit path to enable this.");
      setPhase("unavailable");
      return;
    }

    setMessage("");
    setPhase("loading");
    cancelRequest.current();
    cancelRequest.current = requestGoogleRewardedAd(adUnitPath, {
      onShowing: () => setPhase("showing"),
      onRewardGranted: () => rewardCallback.current(),
      onClosed: (rewarded) => {
        setPhase(rewarded ? "rewarded" : "not-earned");
        setMessage(
          rewarded
            ? "Google confirmed your reward. 50 coins have been added."
            : "The ad closed before a reward was granted. No coins were added.",
        );
      },
      onUnavailable: (reason) => {
        setPhase("unavailable");
        setMessage(reason);
      },
    });
  }

  return {
    phase,
    message,
    configured: Boolean(adUnitPath),
    openPrompt,
    closePrompt,
    continueToAd,
  };
}
