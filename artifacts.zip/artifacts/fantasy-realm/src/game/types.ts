export type GamePage =
  | "home"
  | "character"
  | "inventory"
  | "quests"
  | "battle"
  | "leaderboard";

export type ItemType = "potion" | "material" | "relic";

export interface Player {
  name: string;
  avatar: string;
  level: number;
  xp: number;
  xpToNext: number;
  health: number;
  maxHealth: number;
  mana: number;
  maxMana: number;
  coins: number;
  wins: number;
}

export interface InventoryItem {
  id: string;
  name: string;
  description: string;
  quantity: number;
  type: ItemType;
  icon: string;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  progress: number;
  target: number;
  rewardXp: number;
  rewardCoins: number;
  accepted: boolean;
  claimed: boolean;
}

export interface Battle {
  monsterId: string;
  monsterName: string;
  monsterIcon: string;
  health: number;
  maxHealth: number;
  damage: number;
  turn: number;
  log: string[];
  isOver: boolean;
  won: boolean;
}

export interface LeaderboardEntry {
  name: string;
  level: number;
  xp: number;
  isPlayer: boolean;
}

export interface GameState {
  player: Player;
  inventory: InventoryItem[];
  quests: Quest[];
  battle: Battle | null;
  leaderboard: LeaderboardEntry[];
  page: GamePage;
  notice: string;
}
